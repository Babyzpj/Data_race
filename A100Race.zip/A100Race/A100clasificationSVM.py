# -*- coding: utf-8 -*-
#
# Copyright @2017 R&D, CINS Inc. (cins.com)
#
# Author: PengjunZhu <pengjun.zhu@qq.com>
#
#
# Function:  A100文本分类比赛；11类，训练集和测试集分别在两个文件里，分别有4774条训练数据和2831条测试数据
# 数据集为csv文件，格式为：类别 正文
# 使用svm模型进行分类
#

import csv
import jieba
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.svm import SVC
from sklearn.pipeline import Pipeline
from sklearn import metrics

# 训练集与测试集数据路径
path_train = 'D:/A100Race/training.csv'
path_test  = 'D:/A100Race/testing.csv'
#写入结果文件路径
path_result = 'D:/A100Race/'


# 读取训练集
def readtrain(path):
    with open(path, 'rb') as csvfile:
        reader = csv.reader(csvfile)
        # column1 = [row for row in reader]
        column1 = [row for row in reader]
    content_train = [i[1] for i in column1[:]] #第一列为文本内容，并去除列名
    opinion_train = [i[0] for i in column1[:]] #第二列为类别，并去除列名
    train = [content_train, opinion_train]
    return train


# 对列表进行分词并用空格连接
def segmentWord(cont):
    c = []
    for i in cont:
        a = list(jieba.cut(i))
        b = " ".join(a)
        c.append(b)
    return c

# 准备训练集数据
train = readtrain(path_train)
train_content = segmentWord(train[0])
train_opinion = train[1]

# 准备测试集数据
test = readtrain(path_test)
test_content = segmentWord(test[0])
test_opinion = test[1]


# 转换特征
vectorizer = CountVectorizer()
tfidftransformer = TfidfTransformer()
tfidf = tfidftransformer.fit_transform(vectorizer.fit_transform(train_content)) 


# 训练与预测
text_clf = Pipeline([('vect', CountVectorizer()), ('tfidf', TfidfTransformer()), ('clf', SVC(C=0.98, kernel = 'linear'))])
text_clf = text_clf.fit(train_content, train_opinion)
predicted = text_clf.predict(test_content)


# 将结果写出文件result.csv  
result_file = open(path_result + 'result.csv','w')
for index,item in enumerate(predicted,1): 
    print index,item
    if index < 2381:
        result_file.write(str(index)+','+item + '\n')
    else:
        result_file.write(str(index) + ',' + item )
result_file.close()

